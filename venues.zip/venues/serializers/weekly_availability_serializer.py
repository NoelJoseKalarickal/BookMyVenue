from rest_framework import serializers

from venues.models import WeeklyAvailability


class WeeklyAvailabilitySerializer(serializers.ModelSerializer):

    class Meta:
        model = WeeklyAvailability
        fields = [
            "id",
            "venue",
            "day_of_week",
            "start_time",
            "end_time",
            "minimum_booking_duration_minutes",
            "slot_duration_minutes",
            "buffer_time_minutes",
            "status",
        ]

    def validate(self, data):

        if data["start_time"] >= data["end_time"]:
            raise serializers.ValidationError(
                "Start time must be before end time."
            )

        overlapping = WeeklyAvailability.objects.filter(
            venue=data["venue"],
            day_of_week=data["day_of_week"],
            start_time__lt=data["end_time"],
            end_time__gt=data["start_time"],
        )

        if self.instance:
            overlapping = overlapping.exclude(id=self.instance.id)

        if overlapping.exists():
            raise serializers.ValidationError(
                "This time slot overlaps with an existing slot."
            )

        return data