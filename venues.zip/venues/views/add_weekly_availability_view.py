from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated

from accounts.models import VenueOwner
from venues.models import Venue, WeeklyAvailability


class AddWeeklyAvailabilityView(APIView):

    permission_classes = [IsAuthenticated]

    def post(self, request):

        venue_owner = VenueOwner.objects.filter(
            user=request.user
        ).first()

        if venue_owner is None:
            return Response(
                {
                    "message": "Only venue owners can add weekly availability."
                },
                status=status.HTTP_403_FORBIDDEN
            )

        venue = Venue.objects.filter(
            id=request.data.get("venue"),
            venue_owner=venue_owner
        ).first()

        if venue is None:
            return Response(
                {
                    "message": "Venue not found."
                },
                status=status.HTTP_404_NOT_FOUND
            )

        days = request.data.get("days", [])
        slots = request.data.get("slots", [])

        if not days:
            return Response(
                {
                    "message": "Please select at least one day."
                },
                status=status.HTTP_400_BAD_REQUEST
            )

        if not slots:
            return Response(
                {
                    "message": "Please add at least one time slot."
                },
                status=status.HTTP_400_BAD_REQUEST
            )

        created = []

        for day in days:
            for slot in slots:

                start_time = slot["start_time"]
                end_time = slot["end_time"]

                if start_time >= end_time:
                    return Response(
                        {
                            "message": f"Invalid time slot for {day}."
                        },
                        status=status.HTTP_400_BAD_REQUEST
                    )

                overlap = WeeklyAvailability.objects.filter(
                    venue=venue,
                    day_of_week=day,
                    start_time__lt=end_time,
                    end_time__gt=start_time,
                )

                if overlap.exists():
                    return Response(
                        {
                            "message": f"Overlapping slot found for {day}."
                        },
                        status=status.HTTP_400_BAD_REQUEST
                    )

                availability = WeeklyAvailability.objects.create(
                    venue=venue,
                    day_of_week=day,
                    start_time=start_time,
                    end_time=end_time,
                    minimum_booking_duration_minutes=slot["minimum_booking_duration_minutes"],
                    slot_duration_minutes=slot["slot_duration_minutes"],
                    buffer_time_minutes=slot["buffer_time_minutes"],
                    status=request.data.get("status", "AVAILABLE"),
                )

                created.append(availability.id)

        return Response(
            {
                "message": "Weekly availability added successfully.",
                "created_records": created,
            },
            status=status.HTTP_201_CREATED,
        )