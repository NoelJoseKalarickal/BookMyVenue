from django.db import models

from .venue import Venue


class WeeklyAvailability(models.Model):

    DAYS = [
        ("MONDAY", "Monday"),
        ("TUESDAY", "Tuesday"),
        ("WEDNESDAY", "Wednesday"),
        ("THURSDAY", "Thursday"),
        ("FRIDAY", "Friday"),
        ("SATURDAY", "Saturday"),
        ("SUNDAY", "Sunday"),
    ]

    STATUS_CHOICES = [
        ("AVAILABLE", "Available"),
        ("CLOSED", "Closed"),
    ]

    venue = models.ForeignKey(
        Venue,
        on_delete=models.CASCADE,
        related_name="weekly_availabilities",
    )

    day_of_week = models.CharField(
        max_length=20,
        choices=DAYS,
    )

    start_time = models.TimeField()

    end_time = models.TimeField()

    minimum_booking_duration_minutes = models.PositiveIntegerField(
        default=60,
    )

    slot_duration_minutes = models.PositiveIntegerField(
        default=60,
    )

    buffer_time_minutes = models.PositiveIntegerField(
        default=0,
    )

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default="AVAILABLE",
    )

    def __str__(self):
        return (
            f"{self.venue.venue_name} | "
            f"{self.day_of_week} | "
            f"{self.start_time}-{self.end_time}"
        )